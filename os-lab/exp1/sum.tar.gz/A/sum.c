#include <stdio.h>
int main(){
	int n,sum=0;
	printf("Please input an integer n: ");
	scanf("%d", &n);
	for(int i=1;i<=n;++i)sum+=i;
	printf("The sum from 1 to %d is: %d\n",n,sum);
	return 0;
}
